<script>
	window.location = 'data';
</script>